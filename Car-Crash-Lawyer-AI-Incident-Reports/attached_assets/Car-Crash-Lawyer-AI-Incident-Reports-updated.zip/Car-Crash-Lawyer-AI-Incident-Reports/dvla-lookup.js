const axios = require('axios');

const ; // Use your LIVE or TEST key
const VRM = 'F11NGO'; // Registration mark with no spaces

(async () => {
  try {
    const response = await axios.get('https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles', {
      params: { registrationNumber: VRM },
      headers: {
        'x-api-key': API_KEY,
        'Accept': 'application/json'
      }
    });
    console.log('Vehicle Data:', response.data);
  } catch (error) {
    if (error.response) {
      console.log('Error:', error.response.data);
    } else {
      console.error(error.message);
    }
  }
})();
